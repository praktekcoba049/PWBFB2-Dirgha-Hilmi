<?php

namespace Database\Factories;

use App\Models\Histori;
use Illuminate\Database\Eloquent\Factories\Factory;

class HistoriFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Histori::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
