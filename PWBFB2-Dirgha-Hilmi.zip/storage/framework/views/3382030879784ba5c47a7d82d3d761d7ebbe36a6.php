

<?php $__env->startSection('container'); ?>

    <div class="row">
        
    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Banyak Balita</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($balita->count()); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-table fa-2x text-primary"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Balita Terindikasi Stunting</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($balita->where('STATUS', 1)->count()); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-exclamation-triangle fa-2x text-warning"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                            Balita Stunting</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($balita->where('STATUS', 2)->count()); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-exclamation-circle fa-2x text-danger"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="col-sm-6 py-3">
                <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
            </div>
        </div>
        <div class="row justify-content-md-center">
            <div class="col-md-5 pt-4 pl-3">
                <form action="/balita">
                    <?php echo csrf_field(); ?>
                    <div class="text-center">
                        <h3>Filter</h3>
                    </div>
                    <div class="text-center">
                        <h6 class="text-danger">(*) Pilih salah satu kategori.</h6>
                    </div>
                    <div class="">
                        <select name="kecamatan" class="form-control text-center mt-1">
                            <?php if($statusKec==1): ?>
                            <option value=""><?php echo e(request('kecamatan')); ?></option>
                            <?php else: ?> 
                            <option value="">Pilih Kecamatan</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->KECAMATAN); ?>"><?php echo e($item->KECAMATAN); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="kelurahan" class="form-control text-center mt-1">
                            <?php if($statusKel==1): ?>
                            <option value=""><?php echo e(request('kelurahan')); ?></option>
                            <?php else: ?>
                            <option value="">Pilih Kelurahan</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $kelurahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->KELURAHAN); ?>"><?php echo e($item->KELURAHAN); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="posyandu" class="form-control text-center mt-1">
                            <?php if($statusPos==1): ?>
                            <option value=""><?php echo e(request('posyandu')); ?></option>
                            <?php else: ?>
                            <option value="">Pilih Posyandu</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $posyandu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->NAMA_POSYANDU); ?>"><?php echo e($item->NAMA_POSYANDU); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-8">
                            <a href="/balita" class="btn btn-success">Tampilkan Semua</a> <br/><br/>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" name="" class="btn btn-success btn-user btn-block">
                                Cari
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nama Balita</th>
                            <th>Tanggal Lahir</th>
                            <th>Jenis Kelamin</th>
                            <th>Nama Orangtua</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Nama Balita</th>
                            <th>Tanggal Lahir</th>
                            <th>Jenis Kelamin</th>
                            <th>Nama Orangtua</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $balita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->NAMA_BALITA); ?></td>
                                <td><?php echo e($item->TGL_LAHIR_BALITA); ?></td>
                                <td><?php echo e($item->JENIS_KELAMIN_BALITA); ?></td>
                                <td><?php echo e($item->NAMA_ORANG_TUA); ?></td>
                                <td>
                                    <a href="/edit-kec" class="btn btn-primary tombol">Ubah</a>
                                    <a href="#" class="btn btn-danger tombol" onclick="return confirm('Akan menghapus data');">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>    

<?php echo $__env->make('../admin/layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\PWBFB2-Dirgha-Hilmi\resources\views/admin/master/balita.blade.php ENDPATH**/ ?>