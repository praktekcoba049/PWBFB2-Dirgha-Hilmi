

<?php $__env->startSection('container'); ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Histori Tiap Posyandu</h1>
    <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
        For more information about DataTables, please visit the <a target="_blank"
            href="https://datatables.net">official DataTables documentation</a>.</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
        </div>
        <div class="row justify-content-md-center">
            <div class="col-md-5 pt-4 pl-3">
                <form action="/hposyandu">
                    <?php echo csrf_field(); ?>
                    <div class="text-center">
                        <h3>Filter</h3>
                    </div>
                    <div class="text-center">
                        <h6 class="text-danger">(*) Pilih salah satu kategori.</h6>
                    </div>
                    <div class="">
                        <select name="kecamatan" class="form-control text-center mt-1">
                            <?php if($statusKec==1): ?>
                            <option value=""><?php echo e(request('kecamatan')); ?></option>
                            <?php else: ?> 
                            <option value="">Pilih Kecamatan</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->KECAMATAN); ?>"><?php echo e($item->KECAMATAN); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="kelurahan" class="form-control text-center mt-1">
                            <?php if($statusKel==1): ?>
                            <option value=""><?php echo e(request('kelurahan')); ?></option>
                            <?php else: ?>
                            <option value="">Pilih Kelurahan</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $kelurahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->KELURAHAN); ?>"><?php echo e($item->KELURAHAN); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="posyandu" class="form-control text-center mt-1">
                            <?php if($statusPos==1): ?>
                            <option value=""><?php echo e(request('posyandu')); ?></option>
                            <?php else: ?>
                            <option value="">Pilih Posyandu</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $posyandu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->NAMA_POSYANDU); ?>"><?php echo e($item->NAMA_POSYANDU); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-8">
                            <a href="/hposyandu" class="btn btn-success">Tampilkan Semua</a> <br/><br/>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" name="" class="btn btn-success btn-user btn-block">
                                Cari
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Id Balita</th>
                            <th>BB Balita</th>
                            <th>Tinggi Balita</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Tanggal</th>
                            <th>Id Balita</th>
                            <th>BB Balita</th>
                            <th>Tinggi Balita</th>
                        </tr>
                    </tfoot>
                    
                    <tbody>
                        <?php $__currentLoopData = $hpos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->UPDATED_AT); ?></td>
                                <td><?php echo e($item->NAMA_BALITA); ?></td>
                                <td><?php echo e($item->BERAT_BADAN_BALITA); ?></td>
                                <td><?php echo e($item->TINGGI_BADAN); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>    

<?php echo $__env->make('../admin/layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\PWBFB2-Dirgha-Hilmi\resources\views/admin/master/hposyandu.blade.php ENDPATH**/ ?>