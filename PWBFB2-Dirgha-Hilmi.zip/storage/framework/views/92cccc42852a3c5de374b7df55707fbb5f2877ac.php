

<?php $__env->startSection('container'); ?>
<div>
    <?php if(session()->has('cariError')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('cariError')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tabel Anak Anda</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nama Balita</th>
                        <th>Orang Tua</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Nama Balita</th>
                        <th>Orang Tua</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </tfoot>
                
                <tbody>
                    <?php $__currentLoopData = $balita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->NAMA_BALITA); ?></td>
                        <td><?php echo e($item->NAMA_ORANG_TUA); ?></td>
                        <?php if($item->STATUS==0): ?>
                        <td>Normal</td>
                        <?php endif; ?> 
                        <?php if($item->STATUS==1): ?>
                        <td>Terindikasi Stunting</td>
                        <?php endif; ?>
                        <?php if($item->STATUS==2): ?>
                        <td>Stunting</td>
                        <?php endif; ?>
                        <td>
                            <form action="/orangtua-balita-history" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id_balita" value="<?php echo e($item->ID_BALITA); ?>">
                                <button class="btn btn-success tombol border-0">
                                    History Posyandu
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../ortu/layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\PWBFB2-Dirgha-Hilmi\resources\views/ortu/balita.blade.php ENDPATH**/ ?>