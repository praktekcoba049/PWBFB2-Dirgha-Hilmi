

<?php $__env->startSection('container'); ?>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tabel History Posyandu</h6>
    </div>
    <div class="row justify-content-md-center">
        <div class="col-md-6 pt-4 pl-3">
            <form action="/orangtua">
                <?php echo csrf_field(); ?>
                <div class="text-center">
                    <h3>Histori Posyandu Balita Anda</h3>
                </div>
                <div class="row">
                    <div class="col-md-8">
                        <input type="text" class="form-control" placeholder="Masukkan NIK" name="nik" value="<?php echo e(request('nik')); ?>">
                    </div>
                    <div class="col-md-4">
                        <button type="submit" name="submit" class="btn btn-success btn-user btn-block">
                            Cari
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Id Balita</th>
                        <th>BB Balita</th>
                        <th>Tinggi Balita</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Tanggal</th>
                        <th>Id Balita</th>
                        <th>BB Balita</th>
                        <th>Tinggi Balita</th>
                    </tr>
                </tfoot>
                
                <tbody>
                    <?php if($status==1): ?>
                        <?php $__currentLoopData = $hpos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->UPDATED_AT); ?></td>
                            <td><?php echo e($item->ID_BALITA); ?></td>
                            <td><?php echo e($item->BERAT_BADAN_BALITA); ?></td>
                            <td><?php echo e($item->TINGGI_BADAN); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../ortu/layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\PWBFB2-Dirgha-Hilmi\resources\views/ortu/home.blade.php ENDPATH**/ ?>